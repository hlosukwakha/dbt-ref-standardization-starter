# Master/Reference Data Standardization (dbt starter)

This starter repo helps you standardize reference data (countries, currencies, etc.) across multiple source systems.
It includes:
- Canonical **dim_country** and **dim_currency** models
- **map_country_source** & **map_currency_source** mapping tables
- Seeds for ISO countries, UN M49 regions, ISO 4217 currencies, and common aliases
- Reusable macros and example staging
- Data tests with `dbt_utils`

## Quick start
1. Install dependencies:
   ```bash
   dbt deps
   ```
2. Configure your `profiles.yml` (warehouse connection).
3. Load seeds and run models:
   ```bash
   dbt seed
   dbt run
   dbt test
   ```

## What you need to change
- Replace example staging sources in `models/sources.yml` to point at your real tables.
- Add/extend alias entries in `seeds/country_aliases.csv` for local synonyms ("UK", "Great Britain", etc.).
- (Optional) Update `scripts/fetch_seeds.py` to pull fresh lists from your approved data sources.
